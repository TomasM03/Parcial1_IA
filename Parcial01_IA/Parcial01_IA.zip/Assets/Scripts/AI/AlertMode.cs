public enum AlertMode
{
    None,
    Attack,
    Flee
}
